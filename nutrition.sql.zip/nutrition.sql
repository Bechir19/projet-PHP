-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Jeu 14 Décembre 2023 à 14:39
-- Version du serveur: 4.1.22
-- Version de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `nutrition`
--

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

CREATE TABLE IF NOT EXISTS `panier` (
  `id` varchar(20) NOT NULL default '',
  `idproteine` varchar(20) NOT NULL default '',
  `Nom` varchar(20) NOT NULL default '',
  `Description` varchar(20) NOT NULL default '',
  `Prix` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `panier`
--


-- --------------------------------------------------------

--
-- Structure de la table `proteine`
--

CREATE TABLE IF NOT EXISTS `proteine` (
  `idproteine` int(10) NOT NULL default '0',
  `Nom` varchar(20) NOT NULL default '',
  `Description` varchar(20) NOT NULL default '',
  `Prix` float NOT NULL default '0',
  `image` varchar(224) NOT NULL default '',
  PRIMARY KEY  (`idproteine`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `proteine`
--

INSERT INTO `proteine` (`idproteine`, `Nom`, `Description`, `Prix`, `image`) VALUES
(4, 'rami', 'eeee', 150, ''),
(1111, 'bechir', 'mass musculaire', 111, ''),
(2222, 'bechir', 'mass musculaire', 111, ''),
(121244, 'd', 'd', 150, ''),
(444444, 'creatine', 'seche', 111, ''),
(4444222, 'creatine', 'mass musculaire', 111, ''),
(1212212122, 'bechir', 'mass musculaire', 111, ''),
(2147483647, 'bechir', 'mass musculaire', 111, '');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `Nom` varchar(20) NOT NULL default '',
  `Prenom` varchar(20) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `Mot_passe` varchar(255) default NULL,
  PRIMARY KEY  (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`Nom`, `Prenom`, `email`, `Mot_passe`) VALUES
('bechir', 'hadiden', 'bechirhadiden8@gmail.com', 'sss'),
('bechir', 'hadiden', 'bechirhadiden333@gmail.com', 'ffff'),
('khalil', 'labidi', 'mohamedbechir19@yahoo.fr', 'aaa'),
('creatine', 'monohaydrate', 'jangdo1@starsofchaos.xyz', 'aze'),
('a', 'zz', 'eyamakhlouf@hotmail.fr', 'zzz');
